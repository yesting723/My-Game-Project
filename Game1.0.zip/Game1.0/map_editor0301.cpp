#include <bits/stdc++.h>
using namespace std;

char map0301[11][11];

int main()
{
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			if(i == 3) map0301[i][j] = 'w';
			if(i == 6) map0301[i][j] = 'w';
			if(j == 4) map0301[i][j] = 'w';
			if(i == 8 && j > 5) map0301[i][j] = 'w';
			if(i == 7 && j == 8) map0301[i][j] = 'w';
			if(i == 1 || j == 1) map0301[i][j] = 'e';
			if(i == 10 || j == 10) map0301[i][j] = 'e';
			if(i == 9 && j == 10) map0301[i][j] = 'd';
			if(i == 3 && j == 2) map0301[i][j] = ' ';
			if(i == 6 && j == 7) map0301[i][j] = ' ';
			if(i == 5 && j == 4) map0301[i][j] = ' ';
		}
	}
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			cout << map0301[i][j];
		}
		cout << endl;
	}
	return 0;
}
/*
eeeeeeeeee
e  w     e
e wwwwwwwe
e  w     e
e        e
ewwwww wwe
e  w   w e
e  w wwwwe
e  w     d
eeeeeeeeee
*/

