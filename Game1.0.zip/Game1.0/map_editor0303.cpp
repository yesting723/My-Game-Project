#include <bits/stdc++.h>
using namespace std;

char map0303[11][11];

int main()
{
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			if(i == 3 && j != 2 && j != 9) map0303[i][j] = 'w';
			if(j == 3 && i != 2 && i != 7) map0303[i][j] = 'w';
			if(i == 9 && j >= 2 && j <= 6) map0303[i][j] = 'w';
			if(j == 8 && i >= 2 && i <= 8) map0303[i][j] = 'w';
			if(i == 8 && j == 9) map0303[i][j] = 'w';
			if(i == 7 && j == 6) map0303[i][j] = 'w';
			if(i == 7 && j == 7) map0303[i][j] = 'w';
			if(i == 1 || j == 1) map0303[i][j] = 'e';
			if(i == 10 || j == 10) map0303[i][j] = 'e';
			if(i == 9 && j == 10) map0303[i][j] = 'd';
			if(i == 2 && j == 8) map0303[i][j] = ' ';
		}
	}
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			cout << map0303[i][j];
		}
		cout << endl;
	}
	return 0;
}
/*
eeeeeeeeee
e        e
e wwwwww e
e w    w e
e w    w e
e w    w e
e    www e
e w    wwe
e wwww   d 
eeeeeeeeee
*/

