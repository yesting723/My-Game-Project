#include <bits/stdc++.h>
#include <windows.h>
#include <conio.h>
using namespace std;

char map0301[11][11], map0302[11][11], map0303[11][11];
int p_r,p_l;
int choice;
void act3()
{
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			map0301[i][j] = ' ';
			if(i == 3) map0301[i][j] = 'w';
			if(i == 6) map0301[i][j] = 'w';
			if(j == 4) map0301[i][j] = 'w';
			if(i == 8 && j > 5) map0301[i][j] = 'w';
			if(i == 7 && j == 8) map0301[i][j] = 'w';
			if(i == 1 || j == 1) map0301[i][j] = 'e';
			if(i == 10 || j == 10) map0301[i][j] = 'e';
			if(i == 9 && j == 10) map0301[i][j] = 'd';
			if(i == 3 && j == 2) map0301[i][j] = ' ';
			if(i == 6 && j == 7) map0301[i][j] = ' ';
			if(i == 5 && j == 4) map0301[i][j] = ' ';
		}
	}
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			map0302[i][j] = ' ';
			if(i == 4) map0302[i][j] = 'w';
			if(i == 7) map0302[i][j] = 'w';
			if(j == 5) map0302[i][j] = 'w';
			if(j == 8) map0302[i][j] = 'w';
			if(i == 1 || j == 1) map0302[i][j] = 'e';
			if(i == 10 || j == 10) map0302[i][j] = 'e';
			if(i == 9 && j == 10) map0302[i][j] = 'd';
			if(i == 4 && j == 3) map0302[i][j] = ' ';
			if(i == 7 && j == 3) map0302[i][j] = ' ';
			if(i == 8 && j == 5) map0302[i][j] = ' ';
			if(i == 9 && j == 8) map0302[i][j] = ' ';
		}
	}
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			map0303[i][j] = ' ';
			if(i == 3 && j != 2 && j != 9) map0303[i][j] = 'w';
			if(j == 3 && i != 2 && i != 7) map0303[i][j] = 'w';
			if(i == 9 && j >= 2 && j <= 6) map0303[i][j] = 'w';
			if(j == 8 && i >= 2 && i <= 8) map0303[i][j] = 'w';
			if(i == 8 && j == 9) map0303[i][j] = 'w';
			if(i == 7 && j == 6) map0303[i][j] = 'w';
			if(i == 7 && j == 7) map0303[i][j] = 'w';
			if(i == 1 || j == 1) map0303[i][j] = 'e';
			if(i == 10 || j == 10) map0303[i][j] = 'e';
			if(i == 9 && j == 10) map0303[i][j] = 'd';
			if(i == 2 && j == 8) map0303[i][j] = ' ';
		}
	}
	p_r = 2;
	p_l = 2;
	while(p_r+1 != 10 || p_l+1 != 10)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		map0301[p_r][p_l] = '*';
		for(int i = 1; i <= 10; ++i)
		{
			for(int j = 1; j <= 10; ++j)
			{
				cout << map0301[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0301[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0301[p_r+1][p_l] == 'w' || map0301[p_r+1][p_l] == 'e') continue;
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0301[p_r-1][p_l] == 'w' || map0301[p_r-1][p_l] == 'e') continue;
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0301[p_r][p_l+1] == 'w' || map0301[p_r][p_l+1] == 'e') continue;
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0301[p_r][p_l-1] == 'w' || map0301[p_r][p_l-1] == 'e') continue;
			else p_l--;
		}
		else if(choice == 27) return act3();
		else continue;
	}
	cout << "��ϲͨ��3-1��" << endl;
	cout << endl << endl;
	Sleep(2000);
	p_r = 2;
	p_l = 2;
	while(p_r != 9 || p_l != 9)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		map0302[p_r][p_l] = '*';
		for(int i = 1; i <= 10; ++i)
		{
			for(int j = 1; j <= 10; ++j)
			{
				cout << map0302[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0302[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0302[p_r+1][p_l] == 'w' || map0302[p_r+1][p_l] == 'e') continue;
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0302[p_r-1][p_l] == 'w' || map0302[p_r-1][p_l] == 'e') continue;
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0302[p_r][p_l+1] == 'w' || map0302[p_r][p_l+1] == 'e') continue;
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0302[p_r][p_l-1] == 'w' || map0302[p_r][p_l-1] == 'e') continue;
			else p_l--;
		}
		else if(choice == 27) return act3();
		else continue;
	}
	cout << "��ϲͨ��3-2��" << endl;
	cout << endl << endl;
	Sleep(2000);
	p_r = 2;
	p_l = 2;
	while(p_r != 9 || p_l != 9)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		map0303[p_r][p_l] = '*';
		for(int i = 1; i <= 10; ++i)
		{
			for(int j = 1; j <= 10; ++j)
			{
				cout << map0303[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0303[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0303[p_r+1][p_l] == 'w' || map0303[p_r+1][p_l] == 'e') continue;
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0303[p_r-1][p_l] == 'w' || map0303[p_r-1][p_l] == 'e') continue;
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0303[p_r][p_l+1] == 'w' || map0303[p_r][p_l+1] == 'e') continue;
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0303[p_r][p_l-1] == 'w' || map0303[p_r][p_l-1] == 'e') continue;
			else p_l--;
		}
		else if(choice == 27) return act3();
		else continue;
	}
	cout << "��ϲͨ��3-3�أ�����World4" << endl;
	cout << endl << endl;
	Sleep(2000);
}
int main()
{
	act3();
	return 0;
}
//�������:w=119,a=97,s=115,d=100,esc=27
