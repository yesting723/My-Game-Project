#include <bits/stdc++.h>
using namespace std;
char map0101[8][10];

int main()
{
	for(int i = 1; i <= 8; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0101[i][j] = ' ';
			if(i == 1 || j == 1) map0101[i][j] = 'e';
			if(i == 8 || j == 10) map0101[i][j] = 'e';
			if(i == 7 && j == 10) map0101[i][j] = 'd';
		}
	for(int i = 1; i <= 8; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			cout << map0101[i][j];
		}
		cout << endl;
	}
	return 0;
}
/*
eeeeeeeeee
e        e
e        e
e        e
e        e
e        e
e        d
eeeeeeeeee
*/ 

