#include <bits/stdc++.h>
using namespace std;

char map0302[11][11];

int main()
{
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			if(i == 4) map0302[i][j] = 'w';
			if(i == 7) map0302[i][j] = 'w';
			if(j == 5) map0302[i][j] = 'w';
			if(j == 8) map0302[i][j] = 'w';
			if(i == 1 || j == 1) map0302[i][j] = 'e';
			if(i == 10 || j == 10) map0302[i][j] = 'e';
			if(i == 9 && j == 10) map0302[i][j] = 'd';
			if(i == 4 && j == 3) map0302[i][j] = ' ';
			if(i == 7 && j == 3) map0302[i][j] = ' ';
			if(i == 8 && j == 5) map0302[i][j] = ' ';
			if(i == 9 && j == 8) map0302[i][j] = ' ';
		}
	}
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			cout << map0302[i][j];
		}
		cout << endl;
	}
	return 0;
}
/*
eeeeeeeeee
e   w  w e
e   w  w e
ew wwwwwwe
e   w  w e
e   w  w e
ew wwwmwwe
e      m e
eb  w  w d
eeeeeeeeee
*/

