#include <bits/stdc++.h>
using namespace std;

char map0202[11][11];

int main()
{
	for(int i = 1; i <= 10; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0202[i][j] = ' ';
			if(i == 3) 
			{
				if(j == 3 || j >= 5) map0202[i][j] = 'w';
			}
			if(i == 4) 
			{
				if(j == 3 || j >= 8) map0202[i][j] = 'w';
			}
			if(i == 5) 
			{
				if(j >= 3 && j <= 8) map0202[i][j] = 'w';
			}
			if(i == 6) 
			{
				if(j == 8) map0202[i][j] = 'w';
			}
			if(i == 7) 
			{
				if(j == 6 || j >= 8) map0202[i][j] = 'w';
				else if(j >= 2 && j <= 3) map0202[i][j] = 'w';
			}
			if(i == 8) 
			{
				if(j == 6 || j >= 8) map0202[i][j] = 'w';
			}
			if(i == 9) 
			{
				if(j >= 2 && j <= 6) map0202[i][j] = 'w';
			}
			if(i == 1 || j == 1) map0202[i][j] = 'e';
			if(i == 10 || j == 10) map0202[i][j] = 'e';
			if(i == 9 && j == 10) map0202[i][j] = 'd';
			map0202[9][9] = ' ';
		}
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			cout << map0202[i][j];
		}
		cout << endl;
	}
	return 0;
}
/*
eeeeeeeeee
e        e
e w wwwwwe
e w    wwe
e wwwwww e
e      w e
eww  w w e
e    w w e
ewwwww   d
eeeeeeeeee
*/

