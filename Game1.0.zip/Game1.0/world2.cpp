#include <bits/stdc++.h>
#include <windows.h>
#include <conio.h>
using namespace std;

char map0201[11][11], map0202[11][11], map0203[11][11];
int p_r,p_l;
int choice;
void act2()
{
	for(int i = 1; i <= 10; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0201[i][j] = ' ';
			if(i == j) map0201[i][j] = 'w';
			if(i == 6 && j <= 3) map0201[i][j] = 'w';
			if(i == 8 && j <= 5) map0201[i][j] = 'w';
			if(i == 1 || j == 1) map0201[i][j] = 'e';
			if(i == 10 || j == 10) map0201[i][j] = 'e';
			if(i == 9 && j == 10) map0201[i][j] = 'd';
			map0201[2][2] = ' ';
			map0201[9][9] = ' ';
		}
	for(int i = 1; i <= 10; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0202[i][j] = ' ';
			if(i == 3) 
			{
				if(j == 3 || j >= 5) map0202[i][j] = 'w';
			}
			if(i == 4) 
			{
				if(j == 3 || j >= 8) map0202[i][j] = 'w';
			}
			if(i == 5) 
			{
				if(j >= 3 && j <= 8) map0202[i][j] = 'w';
			}
			if(i == 6) 
			{
				if(j == 8) map0202[i][j] = 'w';
			}
			if(i == 7) 
			{
				if(j == 6 || j >= 8) map0202[i][j] = 'w';
				else if(j >= 2 && j <= 3) map0202[i][j] = 'w';
			}
			if(i == 8) 
			{
				if(j == 6 || j >= 8) map0202[i][j] = 'w';
			}
			if(i == 9) 
			{
				if(j >= 2 && j <= 6) map0202[i][j] = 'w';
			}
			if(i == 1 || j == 1) map0202[i][j] = 'e';
			if(i == 10 || j == 10) map0202[i][j] = 'e';
			if(i == 9 && j == 10) map0202[i][j] = 'd';
			map0202[9][9] = ' ';
		}
	for(int i = 1; i <= 10; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0203[i][j] = ' ';
			if(i == j) map0203[i][j] = 'w';
			if(i + j == 11) map0203[i][j] = 'w';
			if(i == 8 && j == 9) map0203[i][j] = 'w';
			if(i == 2 && j == 2) map0203[i][j] = ' ';
			if(i == 2 && j == 9) map0203[i][j] = ' ';
			if(i == 6 && j == 6) map0203[i][j] = ' ';
			if(i == 9 && j == 9) map0203[i][j] = ' ';
			if(i == 1 || j == 1) map0203[i][j] = 'e';
			if(i == 10 || j == 10) map0203[i][j] = 'e';
			if(i == 9 && j == 10) map0203[i][j] = 'd';
		}
	p_r = 2;
	p_l = 2;
	while(p_r+1 != 10 || p_l+1 != 10)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl; 
		map0201[p_r][p_l] = '*';
		for(int i = 1; i <= 10; ++i)
		{
			for(int j = 1; j <= 10; ++j)
			{
				cout << map0201[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0201[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0201[p_r+1][p_l] == 'w' || map0201[p_r+1][p_l] == 'e') continue;
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0201[p_r-1][p_l] == 'w' || map0201[p_r-1][p_l] == 'e') continue;
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0201[p_r][p_l+1] == 'w' || map0201[p_r][p_l+1] == 'e') continue;
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0201[p_r][p_l-1] == 'w' || map0201[p_r][p_l-1] == 'e') continue;
			else p_l--;
		}
		else if(choice == 27) return act2();
		else continue;
	}
	cout << "��ϲͨ��2-1��" << endl;
	cout << endl << endl;
	Sleep(2000);
	p_r = 2;
	p_l = 2;
	while(p_r != 9 || p_l != 9)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		map0202[p_r][p_l] = '*'; 
		for(int i = 1; i <= 10; ++i)
		{
			for(int j = 1; j <= 10; ++j)
			{
				cout << map0202[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0202[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0202[p_r+1][p_l] == 'w' || map0202[p_r+1][p_l] == 'e') continue;
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0202[p_r-1][p_l] == 'w' || map0202[p_r-1][p_l] == 'e') continue;
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0202[p_r][p_l+1] == 'w' || map0202[p_r][p_l+1] == 'e') continue;
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0202[p_r][p_l-1] == 'w' || map0202[p_r][p_l-1] == 'e') continue;
			else p_l--;
		}
		else if(choice == 27) return act2();
		else continue;
	}
	cout << "��ϲͨ��2-2��" << endl;
	cout << endl << endl;
	Sleep(2000);
	p_r = 2;
	p_l = 2;
	while(p_r != 9 || p_l != 9)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		map0203[p_r][p_l] = '*'; 
		for(int i = 1; i <= 10; ++i)
		{
			for(int j = 1; j <= 10; ++j)
			{
				cout << map0203[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0203[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0203[p_r+1][p_l] == 'w' || map0203[p_r+1][p_l] == 'e') continue;
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0203[p_r-1][p_l] == 'w' || map0203[p_r-1][p_l] == 'e') continue;
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0203[p_r][p_l+1] == 'w' || map0203[p_r][p_l+1] == 'e') continue;
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0203[p_r][p_l-1] == 'w' || map0203[p_r][p_l-1] == 'e') continue;
			else p_l--;
		}
		else if(choice == 27) return act2();
		else continue;
	}
	cout << "��ϲͨ��2-3�أ�����World3" << endl;
	cout << endl << endl;
	Sleep(2000);
}
int main()
{
	act2();
	return 0;
}
//�������:w=119,a=97,s=115,d=100,esc=27
