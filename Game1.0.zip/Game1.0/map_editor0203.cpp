#include <bits/stdc++.h>
using namespace std;

char map0203[11][11];

int main()
{
	for(int i = 1; i <= 10; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0203[i][j] = ' ';
			if(i == j) map0203[i][j] = 'w';
			if(i + j == 11) map0203[i][j] = 'w';
			if(i == 8 && j == 9) map0203[i][j] = 'w';
			if(i == 2 && j == 2) map0203[i][j] = ' ';
			if(i == 2 && j == 9) map0203[i][j] = ' ';
			if(i == 6 && j == 6) map0203[i][j] = ' ';
			if(i == 9 && j == 9) map0203[i][j] = ' ';
			if(i == 1 || j == 1) map0203[i][j] = 'e';
			if(i == 10 || j == 10) map0203[i][j] = 'e';
			if(i == 9 && j == 10) map0203[i][j] = 'd';
		}
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			cout << map0203[i][j];
		}
		cout << endl;
	}
	return 0;
}
/*
eeeeeeeeee
e        e
e w    w e
e  w  w  e
e   ww   e
e   ww   e
e  w  w  e
e w    wwe
ew       d
eeeeeeeeee
*/

