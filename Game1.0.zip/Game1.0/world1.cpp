#include <bits/stdc++.h>
#include <windows.h>
#include <conio.h>
using namespace std;

char map0101[9][11], map0102[11][11], map0103[11][11];
int p_r,p_l;
int choice;

void act1()
{
	for(int i = 1; i <= 8; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0101[i][j] = ' ';
			if(i == 1 || j == 1) map0101[i][j] = 'e';
			if(i == 8 || j == 10) map0101[i][j] = 'e';
			if(i == 7 && j == 10) map0101[i][j] = 'd';
		}
	for(int i = 1; i <= 10; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0102[i][j] = ' ';
			if(i >= 3 && j == 4) map0102[i][j] = 'w';
			if(i <= 8 && j == 7) map0102[i][j] = 'w';
			if(i == 1 || j == 1) map0102[i][j] = 'e';
			if(i == 10 || j == 10) map0102[i][j] = 'e';
			if(i == 2 && j == 10) map0102[i][j] = 'd';
		}
	for(int i = 1; i <= 10; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0103[i][j] = ' ';
			if(i == 4 && j >= 3) map0103[i][j] = 'w';
			if(i == 7 && j <= 8) map0103[i][j] = 'w';
			if(i == 1 || j == 1) map0103[i][j] = 'e';
			if(i == 10 || j == 10) map0103[i][j] = 'e';
			if(i == 9 && j == 1) map0103[i][j] = 'd';
		}
	p_r = 2;
	p_l = 2;
	
	while(p_r+1 != 8 || p_l+1 != 10)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl; 
		map0101[p_r][p_l] = '*';
		for(int i = 1; i <= 8; ++i)
		{
			for(int j = 1; j <= 10; ++j)
			{
				cout << map0101[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0101[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0101[p_r+1][p_l] == 'w' || map0101[p_r+1][p_l] == 'e') continue;
			else p_r+=1;
		}
		else if(choice == 119)
		{
			if(map0101[p_r-1][p_l] == 'w' || map0101[p_r-1][p_l] == 'e') continue;
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0101[p_r][p_l+1] == 'w' || map0101[p_r][p_l+1] == 'e') continue;
			else p_l+=1;
		}
		else if(choice == 97)
		{
			if(map0101[p_r][p_l-1] == 'w' || map0101[p_r][p_l-1] == 'e') continue;
			else p_l--;
		}
		else if(choice == 27) return act1();
		else continue;
	}
	cout << "��ϲͨ��1-1��" << endl;
	cout << endl << endl;
	Sleep(2000);
	p_r = 2;
	p_l = 2;
	while(p_r != 2 || p_l != 9)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl; 
		map0102[p_r][p_l] = '*';
		for(int i = 1; i <= 10; ++i)
		{
			for(int j = 1; j <= 10; ++j)
			{
				cout << map0102[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0102[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0102[p_r+1][p_l] == 'w' || map0102[p_r+1][p_l] == 'e') continue;
			else p_r+=1;
		}
		else if(choice == 119)
		{
			if(map0102[p_r-1][p_l] == 'w' || map0102[p_r-1][p_l] == 'e') continue;
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0102[p_r][p_l+1] == 'w' || map0102[p_r][p_l+1] == 'e') continue;
			else p_l+=1;
		}
		else if(choice == 97)
		{
			if(map0102[p_r][p_l-1] == 'w' || map0102[p_r][p_l-1] == 'e') continue;
			else p_l--;
		}
		else if(choice == 27) return act1();
		else continue;
	}
	cout << "��ϲͨ��1-2��" << endl;
	cout << endl << endl;
	Sleep(2000);
	p_r = 2;
	p_l = 2;
	while(p_r != 9 || p_l != 2)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl; 
		map0103[p_r][p_l] = '*';
		for(int i = 1; i <= 10; ++i)
		{
			for(int j = 1; j <= 10; ++j)
			{
				cout << map0103[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0103[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0103[p_r+1][p_l] == 'w' || map0103[p_r+1][p_l] == 'e') continue;
			else p_r+=1;
		}
		else if(choice == 119)
		{
			if(map0103[p_r-1][p_l] == 'w' || map0103[p_r-1][p_l] == 'e') continue;
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0103[p_r][p_l+1] == 'w' || map0103[p_r][p_l+1] == 'e') continue;
			else p_l+=1;
		}
		else if(choice == 97)
		{
			if(map0103[p_r][p_l-1] == 'w' || map0103[p_r][p_l-1] == 'e') continue;
			else p_l--;
		}
		else if(choice == 27) return act1();
		else continue;
	}
	cout << "��ϲͨ��1-3�أ�����World2" << endl;
	cout << endl << endl;
	Sleep(2000);
}
int main()
{
	act1();
	return 0;
}
//�������:w=119,a=97,s=115,d=100,esc=27

