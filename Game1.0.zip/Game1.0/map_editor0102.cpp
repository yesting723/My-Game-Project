#include <bits/stdc++.h>
using namespace std;

char map0102[10][10];

int main()
{
	for(int i = 1; i <= 10; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0102[i][j] = ' ';
			if(i >= 3 && j == 4) map0102[i][j] = 'w';
			if(i <= 8 && j == 7) map0102[i][j] = 'w';
			if(i == 1 || j == 1) map0102[i][j] = 'e';
			if(i == 10 || j == 10) map0102[i][j] = 'e';
			if(i == 2 && j == 10) map0102[i][j] = 'd';
		}
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			cout << map0102[i][j];
		}
		cout << endl;
	}
	return 0;
}
/*
eeeeeeeeee
e     w  d
e  w  w  e
e  w  w  e
e  w  w  e
e  w  w  e
e  w  w  e
e  w  w  e
e  w     e
eeeeeeeeee
*/


