#include <bits/stdc++.h>
using namespace std;

char map0x0x[11][11];

int main()
{
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			if(i == 1 || j == 1) map0x0x[i][j] = 'e';
			if(i == 10 || j == 10) map0x0x[i][j] = 'e';
			if(i == 9 && j == 10) map0x0x[i][j] = 'd';
		}
	}
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			cout << map0x0x[i][j];
		}
		cout << endl;
	}
	return 0;
}
/*
eeeeeeeeee
ee
ee
ee
ee
ee
ee
ee
ee 
eeeeeeeeee
*/

