#include <bits/stdc++.h>
#include <windows.h>
#include <conio.h>
using namespace std;


int p_r,p_l,bomb;
int choice;



void act7()
{
	char map0701[16][16] = {
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	{'e',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','e'},
	{'e',' ','b','w',' ','w',' ',' ','w','w',' ',' ','w',' ','e'},
	{'e',' ','w',' ',' ',' ','w',' ',' ',' ','w','b','w',' ','e'},
	{'e',' ','w','w',' ','w',' ','w',' ',' ',' ','w',' ',' ','e'},
	{'e',' ','w',' ',' ',' ',' ',' ','w','w',' ','w','w',' ','e'},
	{'e',' ','w',' ','w','w','w',' ','w',' ',' ','m',' ',' ','e'},
	{'e',' ',' ',' ','w','b','w',' ','w',' ','w','w','w','w','e'},
	{'e',' ','w',' ',' ',' ','w',' ','w',' ','w',' ','w','w','e'},
	{'e',' ','w',' ',' ','w','w',' ','w',' ','w',' ',' ',' ','e'},
	{'e',' ','w','w','w',' ','m',' ','w',' ',' ',' ','w',' ','e'},
	{'e',' ','w',' ',' ',' ','w','w','w','w',' ','w','m',' ','e'},
	{'e',' ',' ',' ','w','w',' ',' ','w',' ','w','w',' ','w','e'},
	{'e',' ','w','w',' ',' ',' ',' ','w',' ',' ',' ',' ',' ','d'},
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	};
	
	char map0702[16][16] = {
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	{'e',' ','w','b',' ','w',' ',' ','w',' ',' ','w',' ',' ','e'},
	{'e',' ','m',' ',' ','w',' ',' ','w','w','w','w',' ',' ','e'},
	{'e',' ','w',' ',' ','m','w','w','w',' ',' ','w','w',' ','e'},
	{'e',' ','w','w','w','w',' ',' ','w',' ',' ',' ',' ',' ','e'},
	{'e',' ','w',' ','b','w',' ','w','m',' ',' ','w',' ','w','e'},
	{'e',' ','m',' ',' ','w','w',' ',' ','w','w','w',' ',' ','e'},
	{'e',' ','w',' ',' ','w',' ',' ','w',' ',' ','w','w',' ','e'},
	{'e',' ','w','b',' ','m',' ',' ','w','w','w','w',' ',' ','e'},
	{'e',' ','w','w','w','w',' ',' ','m',' ',' ','w',' ','w','e'},
	{'e',' ','w',' ',' ','w','w','w','w',' ',' ',' ',' ',' ','e'},
	{'e',' ','m',' ',' ','w',' ',' ','w','w','w','w','w',' ','e'},
	{'e',' ','w',' ',' ','w',' ',' ','w',' ',' ','w',' ',' ','e'},
	{'e','b','w',' ',' ',' ',' ',' ','w',' ',' ','w',' ',' ','d'},
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	};
	
	char map0703[16][16] = {
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	{'e',' ',' ',' ',' ',' ',' ','w',' ',' ',' ',' ',' ','m','d'},
	{'e',' ','w',' ','w','w','w','w','w','w',' ',' ','w',' ','e'},
	{'e',' ','w',' ','b','w',' ',' ',' ','w',' ','w',' ',' ','e'},
	{'e',' ','w','w','w','w',' ','w',' ','w',' ','w','w',' ','e'},
	{'e',' ',' ',' ',' ',' ',' ','w',' ','w',' ',' ',' ',' ','e'},
	{'e',' ','w','w','w','w','w','w',' ','w','m','w','w',' ','e'},
	{'e',' ','w','b',' ',' ',' ',' ',' ',' ',' ',' ','w','w','e'},
	{'e',' ','w','w','w',' ','w','w','w',' ','w',' ',' ',' ','e'},
	{'e',' ',' ',' ',' ',' ',' ',' ',' ',' ','w','w','w',' ','e'},
	{'e',' ','w','w','w','w',' ','w','w','w','b',' ','w',' ','e'},
	{'e',' ','w',' ',' ',' ',' ','w',' ',' ',' ',' ','w',' ','e'},
	{'e',' ','w',' ','w','w','w','w',' ',' ',' ',' ','w',' ','e'},
	{'e',' ','w',' ',' ',' ','b','w','b',' ',' ',' ','m',' ','e'},
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	};
	bomb = 0;
	p_r = 1;
	p_l = 1;
	while(p_r != 13 || p_l != 13)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		cout << "ը������" << bomb << endl;
		map0701[p_r][p_l] = '*';
		for(int i = 0; i < 15; ++i)
		{
			for(int j = 0; j < 15; ++j)
			{
				cout << map0701[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0701[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0701[p_r+1][p_l] == 'w' || map0701[p_r+1][p_l] == 'e') continue;
			if(map0701[p_r+1][p_l] == 'b') bomb++;
			if(map0701[p_r+1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0701[p_r+1][p_l] = ' ';
					p_r++;
				}
			}
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0701[p_r-1][p_l] == 'w' || map0701[p_r-1][p_l] == 'e') continue;
			if(map0701[p_r-1][p_l] == 'b') bomb++;
			if(map0701[p_r-1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0701[p_r-1][p_l] = ' ';
					p_r--;
				}
			}
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0701[p_r][p_l+1] == 'w' || map0701[p_r][p_l+1] == 'e') continue;
			if(map0701[p_r][p_l+1] == 'b') bomb++;
			if(map0701[p_r][p_l+1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0701[p_r][p_l+1] = ' ';
					p_l++;
				}
			}
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0701[p_r][p_l-1] == 'w' || map0701[p_r][p_l-1] == 'e') continue;
			if(map0701[p_r][p_l-1] == 'b') bomb++;
			if(map0701[p_r][p_l-1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0701[p_r][p_l-1] = ' ';
					p_l--;
				}
			}
			else p_l--;
		}
		else if(choice == 27)
		{
			return act7();
		}
		else continue;
	}
	cout << "��ϲͨ��7-1��" << endl;
	cout << endl << endl;
	Sleep(2000);
	bomb = 0;
	p_r = 1;
	p_l = 1;
	while(p_r != 13 || p_l != 13)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		cout << "ը������" << bomb << endl;
		map0702[p_r][p_l] = '*';
		for(int i = 0; i < 15; ++i)
		{
			for(int j = 0; j < 15; ++j)
			{
				cout << map0702[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0702[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0702[p_r+1][p_l] == 'w' || map0702[p_r+1][p_l] == 'e') continue;
			if(map0702[p_r+1][p_l] == 'b') bomb++;
			if(map0702[p_r+1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0702[p_r+1][p_l] = ' ';
					p_r++;
				}
			}
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0702[p_r-1][p_l] == 'w' || map0702[p_r-1][p_l] == 'e') continue;
			if(map0702[p_r-1][p_l] == 'b') bomb++;
			if(map0702[p_r-1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0702[p_r-1][p_l] = ' ';
					p_r--;
				}
			}
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0702[p_r][p_l+1] == 'w' || map0702[p_r][p_l+1] == 'e') continue;
			if(map0702[p_r][p_l+1] == 'b') bomb++;
			if(map0702[p_r][p_l+1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0702[p_r][p_l+1] = ' ';
					p_l++;
				}
			}
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0702[p_r][p_l-1] == 'w' || map0702[p_r][p_l-1] == 'e') continue;
			if(map0702[p_r][p_l-1] == 'b') bomb++;
			if(map0702[p_r][p_l-1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0702[p_r][p_l-1] = ' ';
					p_l--;
				}
			}
			else p_l--;
		}
		else if(choice == 27)
		{
			return act7();
		}
		else continue;
	}
	cout << "��ϲͨ��7-2��" << endl;
	cout << endl << endl;
	Sleep(2000);
	bomb = 0;
	p_r = 1;
	p_l = 1;
	while(p_r != 1 || p_l != 13)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		cout << "ը������" << bomb << endl;
		map0703[p_r][p_l] = '*';
		for(int i = 0; i < 15; ++i)
		{
			for(int j = 0; j < 15; ++j)
			{
				cout << map0703[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0703[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0703[p_r+1][p_l] == 'w' || map0703[p_r+1][p_l] == 'e') continue;
			if(map0703[p_r+1][p_l] == 'b') bomb++;
			if(map0703[p_r+1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0703[p_r+1][p_l] = ' ';
					p_r++;
				}
			}
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0703[p_r-1][p_l] == 'w' || map0703[p_r-1][p_l] == 'e') continue;
			if(map0703[p_r-1][p_l] == 'b') bomb++;
			if(map0703[p_r-1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0703[p_r-1][p_l] = ' ';
					p_r--;
				}
			}
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0703[p_r][p_l+1] == 'w' || map0703[p_r][p_l+1] == 'e') continue;
			if(map0703[p_r][p_l+1] == 'b') bomb++;
			if(map0703[p_r][p_l+1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0703[p_r][p_l+1] = ' ';
					p_l++;
				}
			}
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0703[p_r][p_l-1] == 'w' || map0703[p_r][p_l-1] == 'e') continue;
			if(map0703[p_r][p_l-1] == 'b') bomb++;
			if(map0703[p_r][p_l-1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0703[p_r][p_l-1] = ' ';
					p_l--;
				}
			}
			else p_l--;
		}
		else if(choice == 27)
		{
			return act7();
		}
		else continue;
	}
	cout << "��ϲͨ��7-3�أ�����World8" << endl;
	cout << endl << endl;
	Sleep(2000);
}
int main()
{
	act7();
	return 0;
}
//�������:w=119,a=97,s=115,d=100,esc=27
