#include <bits/stdc++.h>
#include <windows.h>
#include <conio.h>
using namespace std;


int p_r,p_l,bomb;
int choice;



void act6()
{
	char map0601[16][16] = {
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	{'e',' ',' ',' ','w','w',' ','w','w','w','w',' ',' ',' ','e'},
	{'e',' ','w',' ','w',' ',' ',' ',' ','w','w',' ',' ',' ','e'},
	{'e',' ','w',' ','w',' ','w','w','m','w','w',' ',' ',' ','e'},
	{'e','b','w',' ',' ',' ','w',' ',' ',' ','m',' ',' ',' ','e'},
	{'e','w','w','w','w','m','w',' ','w','w','w',' ',' ',' ','e'},
	{'e','b','w',' ',' ',' ','w',' ',' ','w','w',' ',' ',' ','e'},
	{'e',' ','w',' ','w',' ','w',' ',' ',' ','w',' ',' ',' ','e'},
	{'e',' ','w',' ','w','w','w','w','w','m','w','w',' ',' ','e'},
	{'e',' ','w',' ',' ',' ','w',' ',' ',' ',' ','w',' ',' ','e'},
	{'e',' ','w','w','w',' ','w',' ','w','w','w','w',' ',' ','e'},
	{'e',' ','w','b','w',' ','w',' ','w',' ',' ','w','w',' ','e'},
	{'e',' ',' ',' ',' ',' ','w',' ',' ',' ','w','w',' ',' ','e'},
	{'e',' ',' ',' ',' ',' ','w',' ',' ',' ',' ',' ',' ',' ','d'},
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	};
	
	char map0602[16][16] = {
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	{'e',' ','w',' ',' ',' ',' ',' ',' ',' ','w',' ',' ',' ','e'},
	{'e',' ','w',' ','w','w',' ',' ',' ',' ','w',' ','w',' ','e'},
	{'e',' ','w',' ','w','w',' ','w','w','w','w',' ','w',' ','e'},
	{'e',' ','w',' ','b','w',' ','w',' ',' ',' ',' ','w',' ','e'},
	{'e',' ','w',' ',' ','w',' ','w',' ','w','w','w','w',' ','e'},
	{'e',' ','w','w','w','w',' ','w',' ','w','b','w',' ',' ','e'},
	{'e',' ',' ',' ',' ',' ',' ',' ',' ','w',' ','w',' ',' ','e'},
	{'e',' ','w','w','w','w','w','w','w','w',' ','w','w','m','e'},
	{'e',' ','w',' ',' ',' ',' ','w',' ',' ',' ',' ',' ',' ','e'},
	{'e',' ','w',' ',' ',' ',' ','w',' ','w',' ',' ',' ',' ','e'},
	{'e',' ','w','w','w','w',' ','w',' ','w',' ',' ',' ',' ','e'},
	{'e',' ',' ',' ',' ',' ',' ','w',' ','w','w','w','w','w','e'},
	{'e',' ',' ',' ',' ',' ',' ','m',' ',' ',' ',' ',' ',' ','d'},
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	};
	
	char map0603[16][16] = {
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	{'e',' ',' ',' ','w',' ',' ',' ',' ',' ',' ',' ',' ',' ','e'},
	{'e',' ',' ',' ',' ','w','w','w','w','m','w','w','w',' ','e'},
	{'e',' ',' ','w',' ','w',' ',' ',' ',' ','w',' ','w',' ','e'},
	{'e',' ',' ','w',' ','w',' ','w','w','w','w',' ','w',' ','e'},
	{'e','w',' ','w',' ','w',' ','w','w',' ',' ',' ','w',' ','e'},
	{'e',' ',' ',' ',' ','w',' ',' ',' ',' ',' ',' ',' ',' ','e'},
	{'e',' ','w','w','w','w','w',' ','w','w','w','b','w',' ','e'},
	{'e',' ',' ',' ',' ','b','w',' ',' ',' ',' ','w','w',' ','e'},
	{'e','w',' ','w','w',' ','w','w',' ','w',' ',' ','w',' ','e'},
	{'e',' ',' ','w',' ',' ','w',' ',' ','w',' ','w','w',' ','e'},
	{'e',' ','w','w',' ','w','w',' ','b','w',' ',' ','w',' ','e'},
	{'e',' ',' ','w',' ',' ','w','w','w','w','m','w','w','m','e'},
	{'e',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','w',' ','d'},
	{'e','e','e','e','e','e','e','e','e','e','e','e','e','e','e'},
	};
	bomb = 0;
	p_r = 1;
	p_l = 1;
	while(p_r != 13 || p_l != 13)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		cout << "ը������" << bomb << endl;
		map0601[p_r][p_l] = '*';
		for(int i = 0; i < 15; ++i)
		{
			for(int j = 0; j < 15; ++j)
			{
				cout << map0601[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0601[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0601[p_r+1][p_l] == 'w' || map0601[p_r+1][p_l] == 'e') continue;
			if(map0601[p_r+1][p_l] == 'b') bomb++;
			if(map0601[p_r+1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0601[p_r+1][p_l] = ' ';
					p_r++;
				}
			}
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0601[p_r-1][p_l] == 'w' || map0601[p_r-1][p_l] == 'e') continue;
			if(map0601[p_r-1][p_l] == 'b') bomb++;
			if(map0601[p_r-1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0601[p_r-1][p_l] = ' ';
					p_r--;
				}
			}
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0601[p_r][p_l+1] == 'w' || map0601[p_r][p_l+1] == 'e') continue;
			if(map0601[p_r][p_l+1] == 'b') bomb++;
			if(map0601[p_r][p_l+1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0601[p_r][p_l+1] = ' ';
					p_l++;
				}
			}
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0601[p_r][p_l-1] == 'w' || map0601[p_r][p_l-1] == 'e') continue;
			if(map0601[p_r][p_l-1] == 'b') bomb++;
			if(map0601[p_r][p_l-1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0601[p_r][p_l-1] = ' ';
					p_l--;
				}
			}
			else p_l--;
		}
		else if(choice == 27)
		{
			return act6();
		}
		else continue;
	}
	cout << "��ϲͨ��6-1��" << endl;
	cout << endl << endl;
	Sleep(2000);
	bomb = 0;
	p_r = 1;
	p_l = 1;
	while(p_r != 13 || p_l != 13)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		cout << "ը������" << bomb << endl;
		map0602[p_r][p_l] = '*';
		for(int i = 0; i < 15; ++i)
		{
			for(int j = 0; j < 15; ++j)
			{
				cout << map0602[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0602[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0602[p_r+1][p_l] == 'w' || map0602[p_r+1][p_l] == 'e') continue;
			if(map0602[p_r+1][p_l] == 'b') bomb++;
			if(map0602[p_r+1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0602[p_r+1][p_l] = ' ';
					p_r++;
				}
			}
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0602[p_r-1][p_l] == 'w' || map0602[p_r-1][p_l] == 'e') continue;
			if(map0602[p_r-1][p_l] == 'b') bomb++;
			if(map0602[p_r-1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0602[p_r-1][p_l] = ' ';
					p_r--;
				}
			}
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0602[p_r][p_l+1] == 'w' || map0602[p_r][p_l+1] == 'e') continue;
			if(map0602[p_r][p_l+1] == 'b') bomb++;
			if(map0602[p_r][p_l+1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0602[p_r][p_l+1] = ' ';
					p_l++;
				}
			}
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0602[p_r][p_l-1] == 'w' || map0602[p_r][p_l-1] == 'e') continue;
			if(map0602[p_r][p_l-1] == 'b') bomb++;
			if(map0602[p_r][p_l-1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0602[p_r][p_l-1] = ' ';
					p_l--;
				}
			}
			else p_l--;
		}
		else if(choice == 27)
		{
			return act6();
		}
		else continue;
	}
	cout << "��ϲͨ��6-2��" << endl;
	cout << endl << endl;
	Sleep(2000);
	bomb = 0;
	p_r = 1;
	p_l = 1;
	while(p_r != 13 || p_l != 13)
	{
		system("cls");
		cout << "���λ�ã�" << p_r << "��" << p_l << "��" << endl;
		cout << "ը������" << bomb << endl;
		map0603[p_r][p_l] = '*';
		for(int i = 0; i < 15; ++i)
		{
			for(int j = 0; j < 15; ++j)
			{
				cout << map0603[i][j] << " ";
			}
			cout << endl;
		}
		choice = _getch();
		map0603[p_r][p_l] = ' ';
		if(choice == 115)
		{
			if(map0603[p_r+1][p_l] == 'w' || map0603[p_r+1][p_l] == 'e') continue;
			if(map0603[p_r+1][p_l] == 'b') bomb++;
			if(map0603[p_r+1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0603[p_r+1][p_l] = ' ';
					p_r++;
				}
			}
			else p_r++;
		}
		else if(choice == 119)
		{
			if(map0603[p_r-1][p_l] == 'w' || map0603[p_r-1][p_l] == 'e') continue;
			if(map0603[p_r-1][p_l] == 'b') bomb++;
			if(map0603[p_r-1][p_l] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0603[p_r-1][p_l] = ' ';
					p_r--;
				}
			}
			else p_r--;
		}
		else if(choice == 100)
		{
			if(map0603[p_r][p_l+1] == 'w' || map0603[p_r][p_l+1] == 'e') continue;
			if(map0603[p_r][p_l+1] == 'b') bomb++;
			if(map0603[p_r][p_l+1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0603[p_r][p_l+1] = ' ';
					p_l++;
				}
			}
			else p_l++;
		}
		else if(choice == 97)
		{
			if(map0603[p_r][p_l-1] == 'w' || map0603[p_r][p_l-1] == 'e') continue;
			if(map0603[p_r][p_l-1] == 'b') bomb++;
			if(map0603[p_r][p_l-1] == 'm')
			{
				if(bomb == 0) continue;
				else
				{
					bomb--;
					map0603[p_r][p_l-1] = ' ';
					p_l--;
				}
			}
			else p_l--;
		}
		else if(choice == 27)
		{
			return act6();
		}
		else continue;
	}
	cout << "��ϲͨ��6-3�أ�����World7" << endl;
	cout << endl << endl;
	Sleep(2000);
}
int main()
{
	act6();
	return 0;
}
//�������:w=119,a=97,s=115,d=100,esc=27
