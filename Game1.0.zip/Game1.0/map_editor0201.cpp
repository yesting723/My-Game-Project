#include <bits/stdc++.h>
using namespace std;

char map0201[11][11];

int main()
{
	for(int i = 1; i <= 10; ++i)
		for(int j = 1; j <= 10; ++j)
		{
			map0201[i][j] = ' ';
			if(i == j) map0201[i][j] = 'w';
			if(i == 6 && j <= 3) map0201[i][j] = 'w';
			if(i == 8 && j <= 5) map0201[i][j] = 'w';
			if(i == 1 || j == 1) map0201[i][j] = 'e';
			if(i == 10 || j == 10) map0201[i][j] = 'e';
			if(i == 9 && j == 10) map0201[i][j] = 'd';
			map0201[9][9] = ' ';
		}
	for(int i = 1; i <= 10; ++i)
	{
		for(int j = 1; j <= 10; ++j)
		{
			cout << map0201[i][j];
		}
		cout << endl;
	}
	return 0;
}
/*
eeeeeeeeee
e        e
e w      e
e  w     e
e   w    e
eww  w   e
e     w  e
ewwww  w e
e        d
eeeeeeeeee
*/

